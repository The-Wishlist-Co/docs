## Shipment Mode

`created_at`	string($date-time)

`id`	string -

`name` - string - name of the mode of shipping

`shipmentCost` -number

`shipmentCostInCent` - integer

`updated_at`	