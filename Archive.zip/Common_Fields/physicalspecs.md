## Physical Specifications 

`dimensionUnitCode` - string - Dimension Unit Code.

`dimensionUnitName` - string - Dimension Unit Name.

`maxDepth` - string - Maximum Depth.

`maxHeight` - Maximum Height.

`maxWeight` - Maximum Weight.

`maxWidth` - Maximum Width.

`minWeight` - Minimum Weight.

`weightUnitCode` - Weight Unit Code.

`weightUnitName` - Weight Unit Name.