
## Attribute Group

`attribute_group` - string - Attribute Group Name.

`attributes` - [AttributeValue](attributeValue.md) - Attributs Values.

`is_obsolete` - boolean - obsolete.
