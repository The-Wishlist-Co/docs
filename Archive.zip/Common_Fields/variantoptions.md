## Variant Options

`optionId` - string - Option Id.

`optionName` - string - Option Name.
