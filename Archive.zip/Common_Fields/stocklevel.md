## Stock Level

`locationRef` - string - Location Reference.

`locationid` - string - Location ID.

`stock` - string - Stock .
