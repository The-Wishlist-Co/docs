## Shipment Line

`created_at` - string($date-time)

`entryId` - string

`entryRef` - string

`id` - string

`orderId` - string

`orderRef` - string

`quantityShipped` - string

`shipmentId` - string

`shipmentLineRef` - string

`shipmentRef` - string

`updated_at` - string($date-time)
