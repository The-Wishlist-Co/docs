## Stock 

`stockLevels` - [StockLevel](stocklevel.md) - Stock Levels.

`totalStock` - string - Total Stocks.