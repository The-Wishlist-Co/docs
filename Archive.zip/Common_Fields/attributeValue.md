## Attribute Value

`attribute_value` - string - Attribute Value.

`value_type` - string - Set of value types.
- INTEGER
- NUMBER
- STRING
- BLOB
- DATE 